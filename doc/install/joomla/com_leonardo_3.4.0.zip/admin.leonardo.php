<?php
/**
 * Leonardo XC server
 */
 
JToolbarHelper::title('Leonardo');
?><p>This component only has a front end part. You can link to this item to display 'Leonardo Server' on the front end</p>